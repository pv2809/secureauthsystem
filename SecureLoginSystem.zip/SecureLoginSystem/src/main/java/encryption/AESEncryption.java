package encryption;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AESEncryption implements EncryptionAlgorithm {
	private static final String ALGORITHM = "AES/ECB/PKCS5Padding";
	private static final String KEY = "MySuperSecretKey"; // 16-byte key

	@Override
	public String encrypt(String input) {
		try {
			SecretKeySpec keySpec = new SecretKeySpec(KEY.getBytes("UTF-8"), "AES");
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.ENCRYPT_MODE, keySpec);
			byte[] encrypted = cipher.doFinal(input.getBytes("UTF-8"));
			return Base64.getEncoder().encodeToString(encrypted);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
