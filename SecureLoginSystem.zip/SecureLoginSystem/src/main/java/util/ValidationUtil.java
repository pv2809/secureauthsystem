package util;

public class ValidationUtil {

	// At least 8 characters, one uppercase letter, one special character, and one
	// digit.
	public static boolean validatePassword(String password) {
		String regex = "^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*\\d).{8,}$";
		return password.matches(regex);
	}

	// Basic email format check.
	public static boolean validateEmail(String email) {
		String regex = "^[\\w-\\.]+@[\\w-]+\\.[a-z]{2,4}$";
		return email.matches(regex);
	}
}
