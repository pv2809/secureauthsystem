package servlets;

import java.io.IOException;

import encryption.AESEncryption;
import encryption.BlowfishEncryption;
import encryption.DESEncryption;
import encryption.MD5Encryption;
import encryption.SHAEncryption;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.User;
import services.UserService;
import util.ValidationUtil;


public class SignupServlet extends HttpServlet {
	private UserService userService = new UserService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("views/signup.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Retrieve form parameters.
		String username = req.getParameter("username");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String confirmPassword = req.getParameter("confirmPassword");
		String dob = req.getParameter("dob"); // Expected format: yyyy-MM-dd

		// Validate required fields.
		if (username == null || email == null || password == null || confirmPassword == null || dob == null
				|| username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()
				|| dob.isEmpty()) { 
			req.setAttribute("error", "All fields are required.");
			req.getRequestDispatcher("views/signup.jsp").forward(req, resp);
			return;
		}

		if (!password.equals(confirmPassword)) {
			req.setAttribute("error", "Passwords do not match.");
			req.getRequestDispatcher("views/signup.jsp").forward(req, resp);
			return;
		}

		if (!ValidationUtil.validatePassword(password)) {
			req.setAttribute("error",
					"Password must be at least 8 characters long, contain one uppercase letter, one digit, and one special character.");
			req.getRequestDispatcher("views/signup.jsp").forward(req, resp);
			return;
		}

		if (!ValidationUtil.validateEmail(email)) {
			req.setAttribute("error", "Invalid email format.");
			req.getRequestDispatcher("views/signup.jsp").forward(req, resp);
			return;
		}

		if (userService.isUsernameExists(username)) {
			req.setAttribute("error", "Username already exists.");
			req.getRequestDispatcher("views/signup.jsp").forward(req, resp);
			return;
		}

		// Encrypt the password using all 5 algorithms.
		String passwordMD5 = new MD5Encryption().encrypt(password);
		String passwordSHA = new SHAEncryption().encrypt(password);
		String passwordAES = new AESEncryption().encrypt(password);
		String passwordDES = new DESEncryption().encrypt(password);
		String passwordBlowfish = new BlowfishEncryption().encrypt(password);

		// Create a new user and register in the DB.
		User user = new User(username, email, dob, passwordMD5, passwordSHA, passwordAES, passwordDES,
				passwordBlowfish);
		userService.registerUser(user);

		// Redirect to the login page on successful signup.
		resp.sendRedirect("views/login.jsp");
	}
}
