package servlets;

import java.io.IOException;

import encryption.AESEncryption;
import encryption.BlowfishEncryption;
import encryption.DESEncryption;
import encryption.MD5Encryption;
import encryption.SHAEncryption;
import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.User;
import services.UserService;
import util.ValidationUtil;

public class PasswordResetServlet extends HttpServlet {
	private UserService userService = new UserService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("views/reset_password.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = (String) req.getSession().getAttribute("resetUsername");
		if (username == null) {
			resp.sendRedirect("login");
			return;
		}

		String newPassword = req.getParameter("newPassword");
		String confirmNewPassword = req.getParameter("confirmNewPassword");

		if (newPassword == null || confirmNewPassword == null || newPassword.isEmpty()
				|| confirmNewPassword.isEmpty()) {
			req.setAttribute("error", "All fields are required.");
			req.getRequestDispatcher("views/reset_password.jsp").forward(req, resp);
			return;
		}

		if (!newPassword.equals(confirmNewPassword)) {
			req.setAttribute("error", "Passwords do not match.");
			req.getRequestDispatcher("views/reset_password.jsp").forward(req, resp);
			return;
		}

		if (!ValidationUtil.validatePassword(newPassword)) {
			req.setAttribute("error", "Password does not meet complexity requirements.");
			req.getRequestDispatcher("views/reset_password.jsp").forward(req, resp);
			return;
		}

		User user = userService.getUserByUsername(username);
		if (user == null) {
			req.setAttribute("error", "User not found.");
			req.getRequestDispatcher("views/reset_password.jsp").forward(req, resp);
			return;
		}

		// Password history check: here using MD5 as an example.
		String newPasswordMD5 = new MD5Encryption().encrypt(newPassword);
		if (newPasswordMD5.equals(user.getPasswordMD5())) {
			req.setAttribute("error", "New password must not match the previous password.");
			req.getRequestDispatcher("views/reset_password.jsp").forward(req, resp);
			return;
		}

		// Encrypt the new password with all algorithms.
		user.setPasswordMD5(newPasswordMD5);
		user.setPasswordSHA(new SHAEncryption().encrypt(newPassword));
		user.setPasswordAES(new AESEncryption().encrypt(newPassword));
		user.setPasswordDES(new DESEncryption().encrypt(newPassword));
		user.setPasswordBlowfish(new BlowfishEncryption().encrypt(newPassword));

		userService.updatePassword(user);
		req.getSession().removeAttribute("resetUsername");
		resp.sendRedirect("login");
	}
}
