package servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.User;
import services.EncryptionService;
import services.LockoutService;
import services.UserService;

public class LoginServlet extends HttpServlet {
	private UserService userService = new UserService();

	@Override
	public void init() throws ServletException {
		// Initialize the dynamic encryption service.
		EncryptionService.init();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("views/login.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");

		if (username == null || password == null || username.isEmpty() || password.isEmpty()) {
			req.setAttribute("error", "Please enter username and password.");
			req.getRequestDispatcher("views/login.jsp").forward(req, resp);
			return;
		}

		// Check for account lockout.
		if (LockoutService.isLocked(username)) {
			req.setAttribute("error", "Your account is locked due to multiple failed login attempts. Try again later.");
			req.getRequestDispatcher("views/login.jsp").forward(req, resp);
			return;
		}

		User user = userService.getUserByUsername(username);
		if (user == null) {
			req.setAttribute("error", "User does not exist.");
			req.getRequestDispatcher("views/login.jsp").forward(req, resp);
			return;
		}

		// Encrypt password input using the currently active algorithm.
		String encryptedInput = EncryptionService.encryptWithActiveAlgorithm(password);

		// Check if the encrypted input matches any stored encrypted version.
		boolean authenticated = encryptedInput.equals(user.getPasswordMD5())
				|| encryptedInput.equals(user.getPasswordSHA()) || encryptedInput.equals(user.getPasswordAES())
				|| encryptedInput.equals(user.getPasswordDES()) || encryptedInput.equals(user.getPasswordBlowfish());

		if (authenticated) {
			LockoutService.resetAttempts(username);
			HttpSession session = req.getSession();
			session.setAttribute("user", user);
			// Redirect to a simple index page on successful login.
			resp.sendRedirect("views/index.jsp");
		} else {
			LockoutService.recordFailedAttempt(username);
			int attempts = LockoutService.getFailedAttempts(username);
			req.setAttribute("error", "Invalid credentials. Failed attempts: " + attempts);
			if (attempts >= 2 && attempts < 6) {
				req.setAttribute("info", "After multiple failures, consider using the 'Forgot Password' option.");
			}
			req.getRequestDispatcher("views/login.jsp").forward(req, resp);
		}
	}
}
