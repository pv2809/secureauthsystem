package servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.User;
import services.UserService;

public class ForgotPasswordServlet extends HttpServlet {
	private UserService userService = new UserService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("views/forgot_password.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String dobDigits = req.getParameter("dobDigits"); // Expected: first 4 digits (year) of the date of birth
		String usernameTail = req.getParameter("usernameTail"); // Last 4 characters of username

		if (username == null || dobDigits == null || usernameTail == null || username.isEmpty() || dobDigits.isEmpty()
				|| usernameTail.isEmpty()) {
			req.setAttribute("error", "All fields are required.");
			req.getRequestDispatcher("views/forgot_password.jsp").forward(req, resp);
			return;
		}

		User user = userService.getUserByUsername(username);
		if (user == null) {
			req.setAttribute("error", "User not found.");
			req.getRequestDispatcher("views/forgot_password.jsp").forward(req, resp);
			return;
		}

		// Validate identity using first 4 digits of DOB and last 4 of username.
		String actualDobDigits = user.getDob().length() >= 4 ? user.getDob().substring(0, 4) : "";
		String actualUsernameTail = user.getUsername().length() >= 4
				? user.getUsername().substring(user.getUsername().length() - 4)
				: "";

		if (dobDigits.equals(actualDobDigits) && usernameTail.equals(actualUsernameTail)) {
			// Identity verified; set session attribute and redirect to reset page.
			req.getSession().setAttribute("resetUsername", username);
			resp.sendRedirect("resetPassword");
		} else {
			req.setAttribute("error", "Identity verification failed.");
			req.getRequestDispatcher("views/forgot_password.jsp").forward(req, resp);
		}
	}
}
