package services;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import encryption.AESEncryption;
import encryption.BlowfishEncryption;
import encryption.DESEncryption;
import encryption.EncryptionAlgorithm;
import encryption.MD5Encryption;
import encryption.SHAEncryption;

public class EncryptionService {
	private static EncryptionAlgorithm activeAlgorithm;

	// Call this once (for example, on app startup) to initialize dynamic switching.
	public static void init() {
		switchAlgorithm();
		Timer timer = new Timer(true);
		// Switch algorithm every 3 minutes (180,000 ms)
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				switchAlgorithm();
			}
		}, 180000, 180000);
	}

	private static void switchAlgorithm() {
		EncryptionAlgorithm[] algorithms = { new MD5Encryption(), new SHAEncryption(), new AESEncryption(),
				new DESEncryption(), new BlowfishEncryption() };
		Random random = new Random();
		activeAlgorithm = algorithms[random.nextInt(algorithms.length)];
		System.out.println("Active encryption algorithm switched to: " + activeAlgorithm.getClass().getSimpleName());
	}

	// Encrypt using the currently active algorithm
	public static String encryptWithActiveAlgorithm(String input) {
		return activeAlgorithm.encrypt(input);
	}
}
