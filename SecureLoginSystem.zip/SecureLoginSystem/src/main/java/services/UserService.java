package services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import config.DBConnection;
import models.User;

public class UserService {

	public boolean isUsernameExists(String username) {
		String sql = "SELECT COUNT(*) FROM users WHERE username=?";
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/secure_login_db", "root", "7815");
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void registerUser(User user) {
		String sql = "INSERT INTO users (username, email, dob, password_md5, password_sha, password_aes, password_des, password_blowfish) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/secure_login_db", "root", "7815");
 PreparedStatement ps = conn.prepareStatement(sql)) {
			System.out.println("user is:,"+user);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getDob());
			ps.setString(4, user.getPasswordMD5());
			ps.setString(5, user.getPasswordSHA());
			ps.setString(6, user.getPasswordAES());
			ps.setString(7, user.getPasswordDES());
			ps.setString(8, user.getPasswordBlowfish());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public User getUserByUsername(String username) {
		String sql = "SELECT * FROM users WHERE username=?";
		try  {
			Connection conn = DriverManager.getConnection(
				    "jdbc:mysql://localhost:3306/secure_login_db?useSSL=false&serverTimezone=UTC", 
				    "root", 
				    "7815"
				);

			 PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setEmail(rs.getString("email"));
				user.setDob(rs.getString("dob"));
				user.setPasswordMD5(rs.getString("password_md5"));
				user.setPasswordSHA(rs.getString("password_sha"));
				user.setPasswordAES(rs.getString("password_aes"));
				user.setPasswordDES(rs.getString("password_des"));
				user.setPasswordBlowfish(rs.getString("password_blowfish"));
				return user;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void updatePassword(User user) {
		String sql = "UPDATE users SET password_md5=?, password_sha=?, password_aes=?, password_des=?, password_blowfish=? WHERE username=?";
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/secure_login_db", "root", "7815");
 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, user.getPasswordMD5());
			ps.setString(2, user.getPasswordSHA());
			ps.setString(3, user.getPasswordAES());
			ps.setString(4, user.getPasswordDES());
			ps.setString(5, user.getPasswordBlowfish());
			ps.setString(6, user.getUsername());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
