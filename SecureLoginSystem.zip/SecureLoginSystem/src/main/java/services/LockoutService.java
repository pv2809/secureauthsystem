package services;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class LockoutService {
	// In-memory maps to track failed attempts and lockout expiry timestamps.
	private static Map<String, Integer> attemptsMap = new ConcurrentHashMap<>();
	private static Map<String, Long> lockoutMap = new ConcurrentHashMap<>();

	// Record a failed login attempt for a user.
	public static void recordFailedAttempt(String username) {
		int attempts = attemptsMap.getOrDefault(username, 0) + 1;
		attemptsMap.put(username, attempts);
		// If 6 or more attempts, lock the account for 30 minutes.
		if (attempts >= 6) {
			lockoutMap.put(username, System.currentTimeMillis() + 30 * 60 * 1000);
			System.out.println("User " + username + " locked out until " + lockoutMap.get(username));
		}
	}

	// Reset the failed login attempts after a successful login.
	public static void resetAttempts(String username) {
		attemptsMap.remove(username);
		lockoutMap.remove(username);
	}

	// Check whether the user’s account is currently locked.
	public static boolean isLocked(String username) {
		if (lockoutMap.containsKey(username)) {
			long lockoutTime = lockoutMap.get(username);
			if (System.currentTimeMillis() < lockoutTime) {
				return true;
			} else {
				// Lockout period has expired.
				lockoutMap.remove(username);
				attemptsMap.remove(username);
			}
		}
		return false;
	}

	public static int getFailedAttempts(String username) {
		return attemptsMap.getOrDefault(username, 0);
	}
}
