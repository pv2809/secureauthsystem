package models;

public class User {
	private int id;
	private String username;
	private String email;
	private String dob;
	private String passwordMD5;
	private String passwordSHA;
	private String passwordAES;
	private String passwordDES;
	private String passwordBlowfish;

	public User() {
	}

	public User(String username, String email, String dob, String passwordMD5, String passwordSHA, String passwordAES,
			String passwordDES, String passwordBlowfish) {
		this.username = username;
		this.email = email;
		this.dob = dob;
		this.passwordMD5 = passwordMD5;
		this.passwordSHA = passwordSHA;
		this.passwordAES = passwordAES;
		this.passwordDES = passwordDES;
		this.passwordBlowfish = passwordBlowfish;
	}

	// Getters and setters for all fields

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getPasswordMD5() {
		return passwordMD5;
	}

	public void setPasswordMD5(String passwordMD5) {
		this.passwordMD5 = passwordMD5;
	}

	public String getPasswordSHA() {
		return passwordSHA;
	}

	public void setPasswordSHA(String passwordSHA) {
		this.passwordSHA = passwordSHA;
	}

	public String getPasswordAES() {
		return passwordAES;
	}

	public void setPasswordAES(String passwordAES) {
		this.passwordAES = passwordAES;
	}

	public String getPasswordDES() {
		return passwordDES;
	}

	public void setPasswordDES(String passwordDES) {
		this.passwordDES = passwordDES;
	}

	public String getPasswordBlowfish() {
		return passwordBlowfish;
	}

	public void setPasswordBlowfish(String passwordBlowfish) {
		this.passwordBlowfish = passwordBlowfish;
	}
}
