package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/secure_login_db";
    private static final String USER = "root";
    private static final String PASSWORD = "7815"; // replace with your actual DB password
    public static void main(String[] args) {
    Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        // Load the JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // establish a connection to the database
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/secure_login_db", "root", "7815");

        // Your SQL query with an intentional error (table name is misspelled)
        String sql = "SELECT * FROM users";

        // create a PreparedStatement
        preparedStatement = connection.prepareStatement(sql);

        // execute the query (this will throw an SQLException in case of an error)
        preparedStatement.executeQuery();
    } catch (SQLException | ClassNotFoundException e) {
    	 handleSQLException((SQLException) e);
        // handle the SQL exception
        
    } 
    finally {
        // close the resources in the finally block
        try {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            handleSQLException(e);
        }
    }
}
    private static void handleSQLException(SQLException e) {
        // handle the SQL exception
        int errorCode = e.getErrorCode();
        String sqlState = e.getSQLState();
        String errorMessage = e.getMessage();

        System.out.println("SQL Error Code: " + errorCode);
        System.out.println("SQL State: " + sqlState);
        System.out.println("Error Message: " + errorMessage);

        e.printStackTrace();
    }
}





 