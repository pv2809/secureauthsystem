package com.secureauth.util;

import java.util.Random;

public class EncryptionRotator {
	private static final String[] ALGORITHMS = { "MD5", "SHA1", "SHA256", "AES", "DES", "Blowfish" };
	private static String currentAlgorithm = "MD5";
	private static final Random random = new Random();

	static {
		// Start the rotator thread
		Thread rotatorThread = new Thread(() -> {
			while (true) {
				try {
					Thread.sleep(3 * 60 * 1000); // 3 minutes
					currentAlgorithm = ALGORITHMS[random.nextInt(ALGORITHMS.length)];
					System.out.println("Switched to algorithm: " + currentAlgorithm);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		rotatorThread.setDaemon(true);
		rotatorThread.start();
	}

	public static String getCurrentAlgorithm() {
		return currentAlgorithm;
	}

	public static String encrypt(String input) throws Exception {
		return switch (currentAlgorithm) {
		case "MD5" -> EncryptionUtil.encryptMD5(input);
		case "SHA1" -> EncryptionUtil.encryptSHA1(input);
		case "SHA256" -> EncryptionUtil.encryptSHA256(input);
		case "AES" -> EncryptionUtil.encryptAES(input);
		case "DES" -> EncryptionUtil.encryptDES(input);
		case "Blowfish" -> EncryptionUtil.encryptBlowfish(input);
		default -> throw new IllegalStateException("Unknown algorithm: " + currentAlgorithm);
		};
	}
}