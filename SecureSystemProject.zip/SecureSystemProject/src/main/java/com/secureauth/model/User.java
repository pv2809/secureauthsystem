package com.secureauth.model;

import java.sql.Date;

public class User {
	private int id;
	private String username;
	private String email;
	private Date dob;
	private String passwordMD5;
	private String passwordSHA1;
	private String passwordSHA256;
	private String passwordAES;
	private String passwordDES;
	private String passwordBlowfish;
	private int failedAttempts;
	private java.sql.Timestamp lockoutTime;
	private String recoveryCode;
	private String passwordHistory;

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getPasswordMD5() {
		return passwordMD5;
	}

	public void setPasswordMD5(String passwordMD5) {
		this.passwordMD5 = passwordMD5;
	}

	public String getPasswordSHA1() {
		return passwordSHA1;
	}

	public void setPasswordSHA1(String passwordSHA1) {
		this.passwordSHA1 = passwordSHA1;
	}

	public String getPasswordSHA256() {
		return passwordSHA256;
	}

	public void setPasswordSHA256(String passwordSHA256) {
		this.passwordSHA256 = passwordSHA256;
	}

	public String getPasswordAES() {
		return passwordAES;
	}

	public void setPasswordAES(String passwordAES) {
		this.passwordAES = passwordAES;
	}

	public String getPasswordDES() {
		return passwordDES;
	}

	public void setPasswordDES(String passwordDES) {
		this.passwordDES = passwordDES;
	}

	public String getPasswordBlowfish() {
		return passwordBlowfish;
	}

	public void setPasswordBlowfish(String passwordBlowfish) {
		this.passwordBlowfish = passwordBlowfish;
	}

	public int getFailedAttempts() {
		return failedAttempts;
	}

	public void setFailedAttempts(int failedAttempts) {
		this.failedAttempts = failedAttempts;
	}

	public java.sql.Timestamp getLockoutTime() {
		return lockoutTime;
	}

	public void setLockoutTime(java.sql.Timestamp lockoutTime) {
		this.lockoutTime = lockoutTime;
	}

	public String getRecoveryCode() {
		return recoveryCode;
	}

	public void setRecoveryCode(String recoveryCode) {
		this.recoveryCode = recoveryCode;
	}

	public String getPasswordHistory() {
		return passwordHistory;
	}

	public void setPasswordHistory(String passwordHistory) {
		this.passwordHistory = passwordHistory;
	}
}
