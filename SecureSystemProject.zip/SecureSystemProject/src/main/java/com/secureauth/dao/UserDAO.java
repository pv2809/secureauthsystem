package com.secureauth.dao;

import com.secureauth.config.DatabaseConfig;
import com.secureauth.model.User;
import com.secureauth.util.EncryptionUtil;
import com.secureauth.util.EncryptionRotator;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

	public void saveUser(User user) throws Exception {
		String sql = "INSERT INTO users (username, email, dob, password_md5, password_sha1, password_sha256, password_aes, password_des, password_blowfish, password_history) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, user.getUsername());
			stmt.setString(2, user.getEmail());
			stmt.setDate(3, user.getDob());
			stmt.setString(4, user.getPasswordMD5());
			stmt.setString(5, user.getPasswordSHA1());
			stmt.setString(6, user.getPasswordSHA256());
			stmt.setString(7, user.getPasswordAES());
			stmt.setString(8, user.getPasswordDES());
			stmt.setString(9, user.getPasswordBlowfish());
			stmt.setString(10, user.getPasswordHistory());
			stmt.executeUpdate();
		}
	}

	public User findUserByUsername(String username) throws SQLException {
		String sql = "SELECT * FROM users WHERE username = ?";
		try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, username);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setEmail(rs.getString("email"));
				user.setDob(rs.getDate("dob"));
				user.setPasswordMD5(rs.getString("password_md5"));
				user.setPasswordSHA1(rs.getString("password_sha1"));
				user.setPasswordSHA256(rs.getString("password_sha256"));
				user.setPasswordAES(rs.getString("password_aes"));
				user.setPasswordDES(rs.getString("password_des"));
				user.setPasswordBlowfish(rs.getString("password_blowfish"));
				user.setFailedAttempts(rs.getInt("failed_attempts"));
				user.setLockoutTime(rs.getTimestamp("lockout_time"));
				user.setRecoveryCode(rs.getString("recovery_code"));
				user.setPasswordHistory(rs.getString("password_history"));
				return user;
			}
			return null;
		}
	}

	public void updateFailedAttempts(String username, int attempts) throws SQLException {
		String sql = "UPDATE users SET failed_attempts = ? WHERE username = ?";
		try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, attempts);
			stmt.setString(2, username);
			stmt.executeUpdate();
		}
	}

	public void lockAccount(String username, LocalDateTime lockoutTime) throws SQLException {
		String sql = "UPDATE users SET lockout_time = ? WHERE username = ?";
		try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setTimestamp(1, Timestamp.valueOf(lockoutTime));
			stmt.setString(2, username);
			stmt.executeUpdate();
		}
	}

	public void updatePassword(User user) throws Exception {
		String sql = "UPDATE users SET password_md5 = ?, password_sha1 = ?, password_sha256 = ?, password_aes = ?, password_des = ?, password_blowfish = ?, password_history = ? WHERE username = ?";
		try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, user.getPasswordMD5());
			stmt.setString(2, user.getPasswordSHA1());
			stmt.setString(3, user.getPasswordSHA256());
			stmt.setString(4, user.getPasswordAES());
			stmt.setString(5, user.getPasswordDES());
			stmt.setString(6, user.getPasswordBlowfish());
			stmt.setString(7, user.getPasswordHistory());
			stmt.setString(8, user.getUsername());
			stmt.executeUpdate();
		}
	}

	public boolean authenticate(String username, String password) throws Exception {
		User user = findUserByUsername(username);
		if (user == null)
			return false;

		LocalDateTime lockoutTime = user.getLockoutTime() != null ? user.getLockoutTime().toLocalDateTime() : null;
		if (lockoutTime != null && lockoutTime.isAfter(LocalDateTime.now())) {
			return false;
		}

		String encryptedPassword = EncryptionRotator.encrypt(password);
		return encryptedPassword.equals(user.getPasswordMD5()) || encryptedPassword.equals(user.getPasswordSHA1())
				|| encryptedPassword.equals(user.getPasswordSHA256()) || encryptedPassword.equals(user.getPasswordAES())
				|| encryptedPassword.equals(user.getPasswordDES())
				|| encryptedPassword.equals(user.getPasswordBlowfish());
	}
}