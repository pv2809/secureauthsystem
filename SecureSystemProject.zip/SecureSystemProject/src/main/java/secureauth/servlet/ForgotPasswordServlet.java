package secureauth.servlet;

import com.secureauth.dao.UserDAO;
import com.secureauth.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/forgotPassword")
public class ForgotPasswordServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String dobDigits = request.getParameter("dob_digits");

		if (username == null || username.isEmpty() || dobDigits == null || dobDigits.isEmpty()) {
			request.setAttribute("error", "All fields are required.");
			request.getRequestDispatcher("/jsp/forgotPassword.jsp").forward(request, response);
			return;
		}

		UserDAO userDAO = new UserDAO();
		try {
			User user = userDAO.findUserByUsername(username);
			if (user == null) {
				request.setAttribute("error", "Invalid username.");
				request.getRequestDispatcher("/jsp/forgotPassword.jsp").forward(request, response);
				return;
			}

			String dob = user.getDob().toString();
			String firstFourDigits = dob.length() >= 4 ? dob.substring(0, 4) : dob;
			if (!dobDigits.equals(firstFourDigits)) {
				request.setAttribute("error", "Invalid DOB digits.");
				request.getRequestDispatcher("/jsp/forgotPassword.jsp").forward(request, response);
				return;
			}

			request.getSession().setAttribute("resetUsername", username);
			response.sendRedirect("jsp/resetPassword.jsp");
		} catch (Exception e) {
			request.setAttribute("error", "An error occurred.");
			request.getRequestDispatcher("/jsp/forgotPassword.jsp").forward(request, response);
		}
	}
}