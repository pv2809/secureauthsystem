package secureauth.servlet;

import com.secureauth.dao.UserDAO;
import com.secureauth.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.time.LocalDateTime;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final int MAX_ATTEMPTS = 2;
	private static final int LOCKOUT_ATTEMPTS = 4;
	private static final int LOCKOUT_MINUTES = 30;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
			request.setAttribute("error", "Username and password are required.");
			request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
			return;
		}

		UserDAO userDAO = new UserDAO();
		try {
			User user = userDAO.findUserByUsername(username);
			if (user == null) {
				request.setAttribute("error", "Invalid username or password.");
				request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
				return;
			}

			LocalDateTime lockoutTime = user.getLockoutTime() != null ? user.getLockoutTime().toLocalDateTime() : null;
			if (lockoutTime != null && lockoutTime.isAfter(LocalDateTime.now())) {
				request.setAttribute("error", "Account is locked. Try again later.");
				request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
				return;
			}

			if (userDAO.authenticate(username, password)) {
				userDAO.updateFailedAttempts(username, 0); // Reset attempts
				HttpSession session = request.getSession();
				session.setAttribute("username", username);
				response.sendRedirect("jsp/welcome.jsp"); // Create a welcome page or redirect as needed
			} else {
				int attempts = user.getFailedAttempts() + 1;
				userDAO.updateFailedAttempts(username, attempts);
				request.setAttribute("failedAttempts", attempts);

				if (attempts >= LOCKOUT_ATTEMPTS) {
					userDAO.lockAccount(username, LocalDateTime.now().plusMinutes(LOCKOUT_MINUTES));
					request.setAttribute("error", "Account locked for 30 minutes.");
					request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
				} else if (attempts >= MAX_ATTEMPTS) {
					response.sendRedirect("jsp/forgotPassword.jsp");
				} else {
					request.setAttribute("error", "Invalid username or password.");
					request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
				}
			}
		} catch (Exception e) {
			request.setAttribute("error", "An error occurred during login.");
			request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
		}
	}
}