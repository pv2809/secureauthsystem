package secureauth.servlet;

import com.secureauth.dao.UserDAO;
import com.secureauth.model.User;
import com.secureauth.util.EncryptionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.regex.Pattern;

@WebServlet("/resetPassword")
public class ResetPasswordServlet extends HttpServlet {
	private static final Pattern PASSWORD_PATTERN = Pattern
			.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = (String) request.getSession().getAttribute("resetUsername");
		String password = request.getParameter("password");
		String confirmPassword = request.getParameter("confirm_password");

		if (username == null || password == null || password.isEmpty() || confirmPassword == null
				|| confirmPassword.isEmpty()) {
			request.setAttribute("error", "All fields are required.");
			request.getRequestDispatcher("/jsp/resetPassword.jsp").forward(request, response);
			return;
		}

		if (!password.equals(confirmPassword)) {
			request.setAttribute("error", "Passwords do not match.");
			request.getRequestDispatcher("/jsp/resetPassword.jsp").forward(request, response);
			return;
		}

		if (!PASSWORD_PATTERN.matcher(password).matches()) {
			request.setAttribute("error",
					"Password must be at least 8 characters, include one uppercase letter, one digit, and one special character.");
			request.getRequestDispatcher("/jsp/resetPassword.jsp").forward(request, response);
			return;
		}

		UserDAO userDAO = new UserDAO();
		try {
			User user = userDAO.findUserByUsername(username);
			if (user == null) {
				request.setAttribute("error", "Invalid session.");
				request.getRequestDispatcher("/jsp/resetPassword.jsp").forward(request, response);
				return;
			}

			String newPasswordHash = EncryptionUtil.encryptSHA256(password);
			if (user.getPasswordHistory() != null && user.getPasswordHistory().contains(newPasswordHash)) {
				request.setAttribute("error", "Cannot reuse previous password.");
				request.getRequestDispatcher("/jsp/resetPassword.jsp").forward(request, response);
				return;
			}

			user.setPasswordMD5(EncryptionUtil.encryptMD5(password));
			user.setPasswordSHA1(EncryptionUtil.encryptSHA1(password));
			user.setPasswordSHA256(EncryptionUtil.encryptSHA256(password));
			user.setPasswordAES(EncryptionUtil.encryptAES(password));
			user.setPasswordDES(EncryptionUtil.encryptDES(password));
			user.setPasswordBlowfish(EncryptionUtil.encryptBlowfish(password));
			user.setPasswordHistory(
					(user.getPasswordHistory() != null ? user.getPasswordHistory() + "," : "") + newPasswordHash);
			user.setFailedAttempts(0);
			user.setLockoutTime(null);

			userDAO.updatePassword(user);
			request.getSession().removeAttribute("resetUsername");
			response.sendRedirect("jsp/login.jsp");
		} catch (Exception e) {
			request.setAttribute("error", "An error occurred during password reset.");
			request.getRequestDispatcher("/jsp/resetPassword.jsp").forward(request, response);
		}
	}
}
